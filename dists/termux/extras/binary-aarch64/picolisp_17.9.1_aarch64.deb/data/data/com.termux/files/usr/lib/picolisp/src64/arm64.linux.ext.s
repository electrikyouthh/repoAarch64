/* 01sep17 */

   .data

   .globl  ExtData
ExtData:

   .globl  SnxTab
SnxTab:
   .byte    48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 0, 0, 0, 0, 0, 0, 0, 0, 70, 83, 84, 0, 70, 83, 0, 0, 83, 83, 76, 78, 78, 0, 70, 83, 82, 83, 84, 0, 70, 70, 83, 0, 83, 0, 0, 0, 0, 0, 0, 0, 70, 83, 84, 0, 70, 83, 0, 0, 83, 83, 76, 78, 78, 0, 70, 83, 82, 83, 84, 0, 70, 70, 83, 0, 83, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 83, 0, 0, 0, 0, 0, 0, 0, 0, 84, 78, 0, 0, 0, 0, 0, 83, 0, 0, 0, 0, 0, 0, 0, 83, 0, 0, 0, 0, 0, 0, 0, 83, 0, 0, 0, 0, 0, 0, 0, 0, 0, 78

   .text

   .globl  ExtCode
ExtCode:

   .balign  8
   .globl  Snx
Snx:
   stp      x21, x30, [x28,-16]!
   str      x22, [x28,-8]!
   mov      x21, x20
   ldr      x22, [x20,8]
   bl       evSymY_E
   cmp      x20, x24
   b.eq     .1
   ldr      x20, [x20,-8]
   bl       nameE_E
   str      x29, [x28,-8]!
   mov      x29, x28
   stp      x29, x20, [x28,-16]!
   mov      x29, x28
   ldr      x22, [x22,8]
   ands     xzr, x22, #0x0E
   b.eq     1f
   mov      x20, #24
1:
   b.ne     .2
   bl       evCntXY_FE
.2:
   ldr      x29, [x28]
   mov      x10, #2
   str      x10, [x28]
   mov      x21, x28
   str      x29, [x28,-8]!
   mov      x29, x28
   mov      x10, #4
   str      x10, [x28,-8]!
   str      x21, [x28,-8]!
   ldr      x21, [x29,16]
   mov      x19, xzr
.3:
   bl       symCharCX_FACX
   b.eq     Snx_90
   cmp      x0, #48
   b.cc     .3
   cmp      x0, #97
   b.cc     .4
   cmp      x0, #122
   b.ls     Snx_40
.4:
   cmp      x0, #128
   b.eq     Snx_40
   cmp      x0, #224
   b.cc     .5
   cmp      x0, #255
   b.hi     .5
Snx_40:
   mov      x10, #-1-32
   and      x0, x0, x10
.5:
   str      x0, [x28,-8]!
   mov      x15, x19
   ldr      x19, [x28,16]
   str      x15, [x28,16]
   mov      x15, x21
   ldr      x21, [x28,8]
   str      x15, [x28,8]
   bl       charSymACX_CX
   mov      x15, x21
   ldr      x21, [x28,8]
   str      x15, [x28,8]
   mov      x15, x19
   ldr      x19, [x28,16]
   str      x15, [x28,16]
.7:
   bl       symCharCX_FACX
   b.eq     Snx_90
   cmp      x0, #32
   b.ls     .7
   subs     x0, x0, #48
   b.cc     Snx_60
   cmp      x0, #194
   b.cs     Snx_60
   adrp     x11, SnxTab
   add      x11, x11, :lo12:SnxTab
   ldrb     w11, [x0,x11]
   bfm      x0, x11, 0, 7
   ubfm     x0, x0, 0, 7
   cmp      x0, 0
   b.ne     .10
Snx_60:
   str      xzr, [x28]
   b        .7
.10:
   ldr      x11, [x28]
   cmp      x0, x11
   b.eq     .7
   subs     x20, x20, #1
   b.eq     Snx_90
   str      x0, [x28]
   mov      x15, x19
   ldr      x19, [x28,16]
   str      x15, [x28,16]
   mov      x15, x21
   ldr      x21, [x28,8]
   str      x15, [x28,8]
   bl       charSymACX_CX
   mov      x15, x21
   ldr      x21, [x28,8]
   str      x15, [x28,8]
   mov      x15, x19
   ldr      x19, [x28,16]
   str      x15, [x28,16]
   b        .7
Snx_90:
   ldr      x21, [x29,8]
   bl       consSymX_E
   ldr      x28, [x29]
   ldr      x29, [x28],8
.1:
   ldp      x22, x21, [x28],16
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  FD
FD:
   stp      x21, x30, [x28,-16]!
   mov      x21, x20
   ldr      x11, [x20,8]
   ldr      x20, [x11]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   str      x20, [x28,-8]!
   bl       xCntEX_FE
   b.mi     .13
   mov      x21, x20
   mov      x0, x20
   bl       initInFileA_A
   mov      x0, x21
   bl       initOutFileA_A
.13:
   ldp      x20, x21, [x28],16
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  Ulaw
Ulaw:
   stp      x21, x30, [x28,-16]!
   mov      x21, x20
   ldr      x11, [x20,8]
   ldr      x20, [x11]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   ands     xzr, x20, #0x02
   b.eq     cntErrEX
   mov      x21, xzr
   sbfm     x9, x20, #4-1, #4-1
   lsr      x20, x20, #4
   ands     xzr, x20, x20
   cbz      x9, .14
   mov      x21, #128
.14:
   movz     x10, 32636, lsl 0
   cmp      x20, x10
   b.cc     .15
   mov      x20, #32635
.15:
   add      x20, x20, #132
   mov      x0, x20
   add      x0, x0, x0
   mov      x19, #7
.16:
   ands     xzr, x0, #32768
   b.ne     .17
   add      x0, x0, x0
   subs     x19, x19, #1
   b.ne     .16
.17:
   mov      x0, x19
   add      x0, x0, #3
   lsr      x20, x20, x0
   and      x20, x20, #15
   lsl      x19, x19, #4
   orr      x20, x20, x19
   orr      x20, x20, x21
   eon      x20, x20, xzr
   and      x20, x20, #255
   lsl      x20, x20, #4
   orr      x20, x20, #2
   ldp      x21, x30, [x28],16
   ret

   .data

   .balign  16
   .globl  Chr64
Chr64:
   .ascii   "A"
Chr64i:
   .ascii   "BCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
Stat64:
   .quad    0
Next64:
   .quad    0

   .text

   .balign  8
   .globl  Base64
Base64:
   str      x30, [x28,-8]!
   ldr      x20, [x20,8]
   ands     xzr, x20, #0x0E
   b.eq     .18
   adrp     x0, :got:Chr
   ldr      x0, [x0, #:got_lo12:Chr]
   ldr      x0, [x0]
   cmp      x0, 0
   b.ne     .20
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
.20:
   cmp      x0, 0
   b.mi     .21
   ubfm     x15, x0, 0, 7
   cmp      x15, #32
   b.hi     .21
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
   b        .20
.21:
   adrp     x19, Chr64
   add      x19, x19, :lo12:Chr64
   ubfm     w1, w0, 0, 7
   mov      x2, x19
   mov      x10, #64
1:
   subs     x10, x10, #1
   b.cc     2f
   ldrb     w3, [x2],1
   cmp      w3, w1
   b.ne     1b
   mov      x19, x2
2:
   b.eq     .22
   ubfm     x15, x0, 0, 7
   cmp      x15, #61
   b.ne     Base64_20
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
   adrp     x13, Stat64
   add      x13, x13, :lo12:Stat64
   ldr      x15, [x13]
   cmp      x15, #1
   b.ne     Base64_20
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
Base64_20:
   adrp     x13, Stat64
   add      x13, x13, :lo12:Stat64
   str      xzr, [x13]
   mov      x20, x24
   ldr      x30, [x28],8
   ret
.22:
   adrp     x11, Chr64i
   add      x11, x11, :lo12:Chr64i
   sub      x19, x19, x11
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
   adrp     x11, Stat64
   add      x11, x11, :lo12:Stat64
   ldr      x11, [x11]
   cmp      x11, 0
   b.ne     .25
   adrp     x0, :got:Chr
   ldr      x0, [x0, #:got_lo12:Chr]
   ldr      x0, [x0]
   adrp     x20, Chr64
   add      x20, x20, :lo12:Chr64
   ubfm     w1, w0, 0, 7
   mov      x2, x20
   mov      x10, #64
1:
   subs     x10, x10, #1
   b.cc     2f
   ldrb     w3, [x2],1
   cmp      w3, w1
   b.ne     1b
   mov      x20, x2
2:
   b.ne     Base64_20
   adrp     x11, Chr64i
   add      x11, x11, :lo12:Chr64i
   sub      x20, x20, x11
   adrp     x13, Next64
   add      x13, x13, :lo12:Next64
   str      x20, [x13]
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
   adrp     x13, Stat64
   add      x13, x13, :lo12:Stat64
   ldr      x15, [x13]
   add      x15, x15, #1
   str      x15, [x13]
   lsl      x19, x19, #6
   and      x20, x20, #48
   b        .26
.25:
   adrp     x20, Next64
   add      x20, x20, :lo12:Next64
   ldr      x20, [x20]
   adrp     x13, Stat64
   add      x13, x13, :lo12:Stat64
   ldr      x15, [x13]
   cmp      x15, #1
   b.ne     .27
   adrp     x13, Stat64
   add      x13, x13, :lo12:Stat64
   ldr      x15, [x13]
   add      x15, x15, #1
   str      x15, [x13]
   adrp     x13, Next64
   add      x13, x13, :lo12:Next64
   str      x19, [x13]
   and      x20, x20, #15
   lsl      x20, x20, #8
   and      x19, x19, #60
   lsl      x19, x19, #2
   b        .26
.27:
   adrp     x13, Stat64
   add      x13, x13, :lo12:Stat64
   str      xzr, [x13]
   and      x20, x20, #3
   lsl      x20, x20, #10
   lsl      x19, x19, #4
.26:
   orr      x20, x20, x19
   orr      x20, x20, #2
   ldr      x30, [x28],8
   ret
.18:
   str      x21, [x28,-8]!
   mov      x21, x20
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   cmp      x20, x24
   b.eq     .29
   str      x22, [x28,-8]!
   lsr      x20, x20, #4
   mov      x22, x20
   lsr      x20, x20, #2
   bl       chr64E
   ldr      x21, [x21,8]
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   cmp      x20, x24
   b.ne     .30
   mov      x20, x22
   and      x20, x20, #3
   lsl      x20, x20, #4
   bl       chr64E
   mov      x10, #61
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x10, #61
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x20, x24
   b        .31
.30:
   lsr      x20, x20, #4
   and      x22, x22, #3
   lsl      x22, x22, #4
   mov      x0, x20
   lsr      x0, x0, #4
   orr      x0, x0, x22
   mov      x22, x20
   bl       chr64A
   ldr      x21, [x21,8]
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   cmp      x20, x24
   b.ne     .32
   mov      x0, x22
   and      x0, x0, #15
   lsl      x0, x0, #2
   bl       chr64A
   mov      x10, #61
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x20, x24
   b        .31
.32:
   lsr      x20, x20, #4
   mov      x0, x20
   lsr      x0, x0, #6
   and      x22, x22, #15
   lsl      x22, x22, #2
   orr      x0, x0, x22
   bl       chr64A
   and      x20, x20, #63
   bl       chr64E
   mov      x20, x25
.31:
   ldr      x22, [x28],8
.29:
   ldp      x21, x30, [x28],16
   ret

   .globl  chr64E
chr64E:
   mov      x0, x20

   .globl  chr64A
chr64A:
   adrp     x11, Chr64
   add      x11, x11, :lo12:Chr64
   ldrb     w11, [x0,x11]
   bfm      x0, x11, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   br       x1
