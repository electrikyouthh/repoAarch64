/* 01sep17 */

   .data

   .globl  HtData
HtData:
HtLt:
   .asciz   "&lt;"
HtGt:
   .asciz   "&gt;"
HtAmp:
   .asciz   "&amp;"
HtQuot:
   .asciz   "&quot;"
HtNbsp:
   .asciz   "&nbsp;"
HtEsc:
   .ascii   " \"#%&:;<=>?_"

   .text

   .globl  HtCode
HtCode:

   .balign  8
   .globl  Prin
Prin:
   stp      x21, x30, [x28,-16]!
   stp      x23, x22, [x28,-16]!
   ldr      x21, [x20,8]
.1:
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   ands     xzr, x20, #0x06
   b.ne     Prin_20
   ands     xzr, x20, #0x0E
   b.eq     Prin_20
   ldrb     w11, [x20,-8]
   tbz      x11, #3, .2
Prin_20:
   bl       prinE_E
   b        .3
.2:
   str      x20, [x28,-8]!
   bl       bufStringE_SZ
   mov      x22, x28
.4:
   ldrb     w11, [x22]
   cbz      x11, .5
   ldrb     w11, [x22]
   bfm      x0, x11, 0, 7
   ubfm     x15, x0, 0, 7
   cmp      x15, #60
   b.ne     .6
   adrp     x19, HtLt
   add      x19, x19, :lo12:HtLt
   bl       outStringC
   b        .7
.6:
   ubfm     x15, x0, 0, 7
   cmp      x15, #62
   b.ne     .8
   adrp     x19, HtGt
   add      x19, x19, :lo12:HtGt
   bl       outStringC
   b        .7
.8:
   ubfm     x15, x0, 0, 7
   cmp      x15, #38
   b.ne     .10
   adrp     x19, HtAmp
   add      x19, x19, :lo12:HtAmp
   bl       outStringC
   b        .7
.10:
   ubfm     x15, x0, 0, 7
   cmp      x15, #34
   b.ne     .12
   adrp     x19, HtQuot
   add      x19, x19, :lo12:HtQuot
   bl       outStringC
   b        .7
.12:
   ubfm     x15, x0, 0, 7
   cmp      x15, #255
   b.ne     .14
   mov      x10, #239
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x10, #191
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x10, #191
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .7
.14:
   mov      x19, x0
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   ands     xzr, x19, #128
   b.eq     .7
   add      x22, x22, #1
   ldrb     w11, [x22]
   bfm      x0, x11, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   ands     xzr, x19, #32
   b.eq     .7
   add      x22, x22, #1
   ldrb     w11, [x22]
   bfm      x0, x11, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
.7:
   add      x22, x22, #1
   b        .4
.5:
   mov      x28, x23
   ldr      x20, [x28],8
.3:
   ldr      x21, [x21,8]
   ands     xzr, x21, #0x0E
   b.eq     .1
   ldp      x23, x22, [x28],16
   ldp      x21, x30, [x28],16
   ret

   .balign  8
   .globl  putHexB
putHexB:
   str      x30, [x28,-8]!
   mov      x20, x0
   mov      x10, #37
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x0, x20
   lsr      x0, x0, #4
   and      x0, x0, #15
   ubfm     x15, x0, 0, 7
   cmp      x15, #9
   b.ls     .18
   add      x0, x0, #7
.18:
   add      x0, x0, #48
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x0, x20
   and      x0, x0, #15
   ubfm     x15, x0, 0, 7
   cmp      x15, #9
   b.ls     .19
   add      x0, x0, #7
.19:
   add      x0, x0, #48
   ldr      x30, [x28],8
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   br       x1

   .balign  8
   .globl  htFmtE
htFmtE:
   str      x30, [x28,-8]!
   cmp      x20, x24
   b.eq     .20
   ands     xzr, x20, #0x06
   b.eq     .21
   mov      x10, #43
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   ldr      x30, [x28],8
   b        prinE
.21:
   str      x21, [x28,-8]!
   ands     xzr, x20, #0x0E
   b.ne     .22
   mov      x21, x20
.23:
   mov      x10, #95
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   ldr      x20, [x21]
   bl       htFmtE
   ldr      x21, [x21,8]
   ands     xzr, x21, #0x0E
   b.eq     .23
   b        .24
.22:
   ldr      x21, [x20,-8]
   bl       nameX_X
   cmp      x21, #2
   b.eq     .24
   ldrb     w11, [x20,-8]
   tbz      x11, #3, .26
   mov      x10, #45
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   bl       prExtNmX
   b        .24
.26:
   str      x22, [x28,-8]!
   bl       isEnvInternEX_FCE
   mov      x19, xzr
   b.ne     .28
   mov      x10, #36
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .30
.28:
   bl       symByteCX_FACX
   ubfm     x15, x0, 0, 7
   cmp      x15, #36
   b.eq     htFmtE_40
   ubfm     x15, x0, 0, 7
   cmp      x15, #43
   b.eq     htFmtE_40
   ubfm     x15, x0, 0, 7
   cmp      x15, #45
   b.ne     htFmtE_50
htFmtE_40:
   bl       putHexB
.30:
   bl       symByteCX_FACX
   b.eq     .31
htFmtE_50:
   ubfm     w1, w0, 0, 7
   adrp     x2, HtEsc
   add      x2, x2, :lo12:HtEsc
   mov      x10, #12
1:
   subs     x10, x10, #1
   b.cc     2f
   ldrb     w3, [x2],1
   cmp      w3, w1
   b.ne     1b
2:
   b.ne     .32
   bl       putHexB
   b        .30
.32:
   mov      x20, x0
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   ands     xzr, x20, #128
   b.eq     .30
   bl       symByteCX_FACX
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   ands     xzr, x20, #32
   b.eq     .30
   bl       symByteCX_FACX
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .30
.31:
   ldr      x22, [x28],8
.24:
   ldr      x21, [x28],8
.20:
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  Fmt
Fmt:
   stp      x21, x30, [x28,-16]!
   stp      x23, x22, [x28,-16]!
   ldr      x21, [x20,8]
   str      x29, [x28,-8]!
   mov      x29, x28
.36:
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   str      x29, [x28,-8]!
   mov      x29, x28
   bl       evListE_E
   ldr      x29, [x28],8
2:
   str      x20, [x28,-8]!
   ldr      x21, [x21,8]
   ands     xzr, x21, #0x0E
   b.eq     .36
   mov      x11, -8
   add      x22, x29, x11
   mov      x23, x28
   str      x29, [x28,-8]!
   mov      x29, x28
   bl       begString_S
   ldr      x20, [x22]
   bl       htFmtE
.37:
   cmp      x22, x23
   b.eq     .38
   mov      x10, #38
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   sub      x22, x22, #8
   ldr      x20, [x22]
   bl       htFmtE
   b        .37
.38:
   bl       endStringS_E
   ldr      x28, [x29]
   ldp      x29, x23, [x28],16
   ldp      x22, x21, [x28],16
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  getHexX_A
getHexX_A:
   str      x30, [x28,-8]!
   ldr      x11, [x21]
   ldr      x0, [x11,-8]
   bl       firstByteA_B
   sub      x0, x0, #48
   ubfm     x15, x0, 0, 7
   cmp      x15, #9
   b.ls     .39
   movz     x10, 223, lsl 0
   and      x0, x0, x10
   sub      x0, x0, #7
.39:
   ldr      x21, [x21,8]
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  getUnicodeX_FAX
getUnicodeX_FAX:
   str      x30, [x28,-8]!
   mov      x20, x21
   mov      x19, xzr
.40:
   ldr      x21, [x21,8]
   ldr      x11, [x21]
   ldr      x0, [x11,-8]
   bl       firstByteA_B
   ubfm     x15, x0, 0, 7
   cmp      x15, #48
   b.cc     .41
   ubfm     x15, x0, 0, 7
   cmp      x15, #57
   b.hi     .41
   sub      x0, x0, #48
   str      x0, [x28,-8]!
   mov      x0, x19
   mov      x15, #10
   umulh    x19, x0, x15
   mul      x0, x0, x15
   ldr      x19, [x28],8
   add      x19, x19, x0
   b        .40
.41:
   ubfm     x15, x0, 0, 7
   cmp      x15, #59
   b.ne     .42
   ldr      x21, [x21,8]
   mov      x0, x19
   cmp      x0, 0
   b.ne     getUnicodeX_FAX_90
.42:
   mov      x21, x20
   cmp      xzr, xzr
getUnicodeX_FAX_90:
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  headCX_FX
headCX_FX:
   str      x30, [x28,-8]!
   mov      x20, x21
.43:
   add      x19, x19, #1
   ldrb     w11, [x19]
   cmp      x11, 0
   b.eq     .44
   ldr      x11, [x21]
   ldr      x0, [x11,-8]
   bl       firstByteA_B
   ubfm     x15, x0, 0, 7
   ldrb     w11, [x19]
   cmp      x15, x11
   b.ne     .44
   ldr      x21, [x21,8]
   b        .43
.44:
   csel     x21, x20, x21, ne
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  Pack
Pack:
   stp      x21, x30, [x28,-16]!
   str      x22, [x28,-8]!
   ldr      x21, [x20,8]
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   str      x29, [x28,-8]!
   mov      x29, x28
   stp      x29, x20, [x28,-16]!
   mov      x29, x28
   ldr      x11, [x21,8]
   ldr      x20, [x11]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   mov      x22, x20
   ldr      x21, [x29,8]
   bl       begString_S
.45:
   ands     xzr, x21, #0x0E
   b.ne     .46
   ldr      x20, [x21]
   ldr      x0, [x20,-8]
   bl       firstByteA_B
   ubfm     x15, x0, 0, 7
   cmp      x15, #37
   b.ne     .47
   ldr      x21, [x21,8]
   cmp      x22, x24
   b.eq     .48
   bl       getHexX_A
   lsl      x0, x0, #4
   mov      x19, x0
   bl       getHexX_A
   orr      x0, x0, x19
.48:
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .45
.47:
   ldr      x21, [x21,8]
   ubfm     x15, x0, 0, 7
   cmp      x15, #38
   b.eq     .50
   bl       outNameE
   b        .45
.50:
   adrp     x19, HtLt
   add      x19, x19, :lo12:HtLt
   bl       headCX_FX
   b.ne     .52
   mov      x10, #60
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .45
.52:
   adrp     x19, HtGt
   add      x19, x19, :lo12:HtGt
   bl       headCX_FX
   b.ne     .54
   mov      x10, #62
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .45
.54:
   adrp     x19, HtAmp
   add      x19, x19, :lo12:HtAmp
   bl       headCX_FX
   b.ne     .56
   mov      x10, #38
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .45
.56:
   adrp     x19, HtQuot
   add      x19, x19, :lo12:HtQuot
   bl       headCX_FX
   b.ne     .58
   mov      x10, #34
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .45
.58:
   adrp     x19, HtNbsp
   add      x19, x19, :lo12:HtNbsp
   bl       headCX_FX
   b.ne     .60
   mov      x10, #32
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .45
.60:
   ldr      x11, [x21]
   ldr      x0, [x11,-8]
   bl       firstByteA_B
   ubfm     x15, x0, 0, 7
   cmp      x15, #35
   b.ne     Pack_40
   bl       getUnicodeX_FAX
   b.eq     Pack_40
   bl       mkCharA_A
   mov      x20, x0
   bl       outNameE
   b        .45
Pack_40:
   mov      x10, #38
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   b        .45
.46:
   bl       endStringS_E
   ldr      x28, [x29]
   ldp      x29, x22, [x28],16
   ldp      x21, x30, [x28],16
   ret

   .balign  8
   .globl  Read
Read:
   stp      x21, x30, [x28,-16]!
   mov      x21, x20
   ldr      x11, [x20,8]
   ldr      x20, [x11]
   bl       evCntEX_FE
   b.le     .64
   adrp     x0, :got:Chr
   ldr      x0, [x0, #:got_lo12:Chr]
   ldr      x0, [x0]
   cmp      x0, 0
   b.ne     .65
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
.65:
   cmp      x0, 0
   b.mi     .64
   bl       getChar_A
   cmp      x0, #128
   b.cc     .67
   sub      x20, x20, #1
   cmp      x0, #2048
   b.cc     .67
   sub      x20, x20, #1
.67:
   subs     x20, x20, #1
   b.mi     .64
   bl       mkCharA_A
   bl       consA_X
   str      x0, [x21]
   str      x24, [x21,8]
   str      x29, [x28,-8]!
   mov      x29, x28
   stp      x29, x21, [x28,-16]!
   mov      x29, x28
.70:
   cmp      x20, 0
   b.ne     .71
   ldr      x20, [x29,8]
   b        .72
.71:
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x1, [x11]
   blr      x1
   cmp      x0, 0
   b.pl     .73
   mov      x20, x24
   b        .72
.73:
   bl       getChar_A
   cmp      x0, #128
   b.cc     .74
   sub      x20, x20, #1
   cmp      x0, #2048
   b.cc     .74
   sub      x20, x20, #1
.74:
   subs     x20, x20, #1
   b.pl     .76
   mov      x20, x24
   b        .72
.76:
   bl       mkCharA_A
   bl       consA_C
   str      x0, [x19]
   str      x24, [x19,8]
   str      x19, [x21,8]
   mov      x21, x19
   b        .70
.72:
   adrp     x13, :got:Chr
   ldr      x13, [x13, #:got_lo12:Chr]
   str      xzr, [x13]
   ldr      x28, [x29]
   ldp      x29, x21, [x28],16
   ldr      x30, [x28],8
   ret
.64:
   mov      x20, x24
   ldp      x21, x30, [x28],16
   ret

   .data

   .balign  16
   .globl  Chunk
Chunk:
   .quad    0
   .quad    0
   .quad    0
   .space   4000
Newlines:
   .asciz   "0\r\n\r\n"

   .text

   .balign  8
   .globl  chrHex_AF
chrHex_AF:
   adrp     x0, :got:Chr
   ldr      x0, [x0, #:got_lo12:Chr]
   ldr      x0, [x0]
   ubfm     x15, x0, 0, 7
   cmp      x15, #48
   b.cc     .77
   ubfm     x15, x0, 0, 7
   cmp      x15, #57
   b.hi     .77
   subs     x0, x0, #48
   ret
.77:
   movz     x10, 223, lsl 0
   and      x0, x0, x10
   ubfm     x15, x0, 0, 7
   cmp      x15, #65
   b.cc     .79
   ubfm     x15, x0, 0, 7
   cmp      x15, #70
   b.hi     .79
   subs     x0, x0, #55
   ret
.79:
   mov      x0, xzr
   subs     x0, x0, #1
   ret

   .balign  8
   .globl  chunkSize
chunkSize:
   stp      x21, x30, [x28,-16]!
   adrp     x21, Chunk
   add      x21, x21, :lo12:Chunk
   adrp     x11, :got:Chr
   ldr      x11, [x11, #:got_lo12:Chr]
   ldr      x11, [x11]
   cmp      x11, 0
   b.ne     .81
   ldr      x0, [x21,8]
   blr      x0
.81:
   bl       chrHex_AF
   str      x0, [x21]
   b.cc     chunkSize_90
.83:
   ldr      x0, [x21,8]
   blr      x0
   bl       chrHex_AF
   b.cc     .85
   ldr      x19, [x21]
   lsl      x19, x19, #4
   orr      x19, x19, x0
   str      x19, [x21]
   b        .83
.85:
   adrp     x13, :got:Chr
   ldr      x13, [x13, #:got_lo12:Chr]
   ldr      x15, [x13]
   cmp      x15, #10
   b.eq     .86
   adrp     x11, :got:Chr
   ldr      x11, [x11, #:got_lo12:Chr]
   ldr      x11, [x11]
   cmp      x11, 0
   b.mi     chunkSize_90
   ldr      x0, [x21,8]
   blr      x0
   b        .85
.86:
   ldr      x0, [x21,8]
   blr      x0
   ldr      x11, [x21]
   cmp      x11, 0
   b.ne     chunkSize_90
   ldr      x0, [x21,8]
   blr      x0
   adrp     x13, :got:Chr
   ldr      x13, [x13, #:got_lo12:Chr]
   str      xzr, [x13]
chunkSize_90:
   ldp      x21, x30, [x28],16
   ret

   .balign  8
   .globl  getChunked_A
getChunked_A:
   stp      x22, x30, [x28,-16]!
   adrp     x22, Chunk
   add      x22, x22, :lo12:Chunk
   ldr      x11, [x22]
   cmp      x11, 0
   b.gt     .88
   mov      x0, #-1
   adrp     x13, :got:Chr
   ldr      x13, [x13, #:got_lo12:Chr]
   str      x0, [x13]
   b        .89
.88:
   ldr      x0, [x22,8]
   blr      x0
   ldr      x15, [x22]
   subs     x15, x15, #1
   str      x15, [x22]
   b.ne     .89
   ldr      x0, [x22,8]
   blr      x0
   ldr      x0, [x22,8]
   blr      x0
   bl       chunkSize
.89:
   ldp      x22, x30, [x28],16
   ret

   .balign  8
   .globl  In
In:
   stp      x21, x30, [x28,-16]!
   ldr      x21, [x20,8]
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   ldr      x21, [x21,8]
   cmp      x20, x24
   b.ne     .91
1:
   ldr      x20, [x21]
   ands     wzr, w20, #0x06
   b.ne     3f
   tbz      w20, #3, 2f
   ldr      x20, [x20]
   b        3f
2:
   bl       evListE_E
3:
   ldr      x21, [x21,8]
   ands     xzr, x21, #0x0E
   b.eq     1b
   b        .92
.91:
   str      x22, [x28,-8]!
   adrp     x22, Chunk
   add      x22, x22, :lo12:Chunk
   adrp     x11, :got:Get_A
   ldr      x11, [x11, #:got_lo12:Get_A]
   ldr      x11, [x11]
   str      x11, [x22,8]
   adrp     x13, :got:Get_A
   ldr      x13, [x13, #:got_lo12:Get_A]
   adrp     x11, getChunked_A
   add      x11, x11, :lo12:getChunked_A
   str      x11, [x13]
   bl       chunkSize
1:
   ldr      x20, [x21]
   ands     wzr, w20, #0x06
   b.ne     3f
   tbz      w20, #3, 2f
   ldr      x20, [x20]
   b        3f
2:
   bl       evListE_E
3:
   ldr      x21, [x21,8]
   ands     xzr, x21, #0x0E
   b.eq     1b
   adrp     x13, :got:Get_A
   ldr      x13, [x13, #:got_lo12:Get_A]
   ldr      x11, [x22,8]
   str      x11, [x13]
   adrp     x13, :got:Chr
   ldr      x13, [x13, #:got_lo12:Chr]
   str      xzr, [x13]
   ldr      x22, [x28],8
.92:
   ldp      x21, x30, [x28],16
   ret

   .balign  8
   .globl  outHexA
outHexA:
   str      x30, [x28,-8]!
   cmp      x0, #15
   b.ls     .93
   str      x0, [x28,-8]!
   lsr      x0, x0, #4
   bl       outHexA
   ldr      x0, [x28],8
   and      x0, x0, #15
.93:
   ubfm     x15, x0, 0, 7
   cmp      x15, #9
   b.ls     .94
   add      x0, x0, #39
.94:
   add      x0, x0, #48
   ldr      x30, [x28],8
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   br       x1

   .balign  8
   .globl  wrChunkY
wrChunkY:
   str      x30, [x28,-8]!
   adrp     x13, :got:PutB
   ldr      x13, [x13, #:got_lo12:PutB]
   ldr      x11, [x22,16]
   str      x11, [x13]
   ldr      x0, [x22]
   bl       outHexA
   mov      x10, #13
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x10, #10
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   add      x21, x22, 24
.95:
   ldrb     w11, [x21]
   bfm      x0, x11, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   add      x21, x21, #1
   ldr      x15, [x22]
   subs     x15, x15, #1
   str      x15, [x22]
   b.ne     .95
   mov      x10, #13
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   mov      x10, #10
   bfm      x0, x10, 0, 7
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x1, [x11]
   blr      x1
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x11, [x11]
   str      x11, [x22,16]
   adrp     x13, :got:PutB
   ldr      x13, [x13, #:got_lo12:PutB]
   adrp     x11, putChunkedB
   add      x11, x11, :lo12:putChunkedB
   str      x11, [x13]
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  putChunkedB
putChunkedB:
   stp      x21, x30, [x28,-16]!
   str      x22, [x28,-8]!
   adrp     x22, Chunk
   add      x22, x22, :lo12:Chunk
   add      x21, x22, 24
   ldr      x11, [x22]
   add      x21, x21, x11
   strb     w0, [x21]
   ldr      x15, [x22]
   add      x15, x15, #1
   str      x15, [x22]
   ldr      x15, [x22]
   cmp      x15, #4000
   b.ne     .96
   bl       wrChunkY
.96:
   ldp      x22, x21, [x28],16
   ldr      x30, [x28],8
   ret

   .balign  8
   .globl  Out
Out:
   stp      x21, x30, [x28,-16]!
   ldr      x21, [x20,8]
   ldr      x20, [x21]
   ands     xzr, x20, #0x06
   b.ne     2f
   tbz      x20, #3, 1f
   ldr      x20, [x20]
   b        2f
1:
   bl       evListE_E
2:
   ldr      x21, [x21,8]
   cmp      x20, x24
   b.ne     .97
1:
   ldr      x20, [x21]
   ands     wzr, w20, #0x06
   b.ne     3f
   tbz      w20, #3, 2f
   ldr      x20, [x20]
   b        3f
2:
   bl       evListE_E
3:
   ldr      x21, [x21,8]
   ands     xzr, x21, #0x0E
   b.eq     1b
   b        .98
.97:
   str      x22, [x28,-8]!
   adrp     x22, Chunk
   add      x22, x22, :lo12:Chunk
   str      xzr, [x22]
   adrp     x11, :got:PutB
   ldr      x11, [x11, #:got_lo12:PutB]
   ldr      x11, [x11]
   str      x11, [x22,16]
   adrp     x13, :got:PutB
   ldr      x13, [x13, #:got_lo12:PutB]
   adrp     x11, putChunkedB
   add      x11, x11, :lo12:putChunkedB
   str      x11, [x13]
1:
   ldr      x20, [x21]
   ands     wzr, w20, #0x06
   b.ne     3f
   tbz      w20, #3, 2f
   ldr      x20, [x20]
   b        3f
2:
   bl       evListE_E
3:
   ldr      x21, [x21,8]
   ands     xzr, x21, #0x0E
   b.eq     1b
   ldr      x11, [x22]
   cmp      x11, 0
   b.eq     .99
   bl       wrChunkY
.99:
   adrp     x13, :got:PutB
   ldr      x13, [x13, #:got_lo12:PutB]
   ldr      x11, [x22,16]
   str      x11, [x13]
   adrp     x19, Newlines
   add      x19, x19, :lo12:Newlines
   bl       outStringC
   ldr      x22, [x28],8
.98:
   adrp     x0, :got:OutFile
   ldr      x0, [x0, #:got_lo12:OutFile]
   ldr      x0, [x0]
   bl       flushA_F
   ldp      x21, x30, [x28],16
   ret
