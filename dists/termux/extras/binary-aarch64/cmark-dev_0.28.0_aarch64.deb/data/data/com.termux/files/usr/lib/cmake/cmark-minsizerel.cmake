#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cmark" for configuration "MinSizeRel"
set_property(TARGET cmark APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(cmark PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/cmark"
  )

list(APPEND _IMPORT_CHECK_TARGETS cmark )
list(APPEND _IMPORT_CHECK_FILES_FOR_cmark "${_IMPORT_PREFIX}/bin/cmark" )

# Import target "libcmark" for configuration "MinSizeRel"
set_property(TARGET libcmark APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(libcmark PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libcmark.so"
  IMPORTED_SONAME_MINSIZEREL "libcmark.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS libcmark )
list(APPEND _IMPORT_CHECK_FILES_FOR_libcmark "${_IMPORT_PREFIX}/lib/libcmark.so" )

# Import target "libcmark_static" for configuration "MinSizeRel"
set_property(TARGET libcmark_static APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(libcmark_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "C"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libcmark.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS libcmark_static )
list(APPEND _IMPORT_CHECK_FILES_FOR_libcmark_static "${_IMPORT_PREFIX}/lib/libcmark.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
