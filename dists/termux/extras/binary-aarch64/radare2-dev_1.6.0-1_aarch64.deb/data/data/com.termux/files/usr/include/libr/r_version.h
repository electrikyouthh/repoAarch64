#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R2_VERSION_COMMIT 0
#define R2_GITTAP "1.6.0"
#define R2_GITTIP "HEAD"
#define R2_BIRTH "2017-09-12__12:27:49"
#endif
