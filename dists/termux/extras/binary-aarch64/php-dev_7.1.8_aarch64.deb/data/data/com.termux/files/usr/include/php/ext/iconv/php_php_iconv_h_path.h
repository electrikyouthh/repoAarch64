#define PHP_ICONV_H_PATH </data/data/com.termux/files/usr/include/iconv.h>
